function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
  }